#!/usr/bin/env python3
"""
CryptoBuddy - A friendly cryptocurrency investment advice chatbot.

This chatbot provides educational cryptocurrency information and investment
guidance using rule-based logic and predefined cryptocurrency data.

Features:
- Interactive conversation with friendly responses
- Rule-based advice on trending, sustainable, and energy-efficient cryptocurrencies
- Optional live data fetching from CoinGecko API
- Basic NLP processing for better user interaction
- Investment disclaimer and risk awareness

Usage:
    python main.py

Author: CryptoBuddy Team
Version: 1.0.0
"""

import sys
import os
from chatbot import CryptoBuddy

def main():
    """Main entry point for CryptoBuddy chatbot."""
    print("=" * 60)
    print("🚀 CRYPTOBUDDY - Your Friendly Crypto Investment Advisor 🚀")
    print("=" * 60)
    
    try:
        # Initialize chatbot with live data enabled by default
        # Set use_live_data=False to use only predefined data
        chatbot = CryptoBuddy(use_live_data=True)
        
        # Start the chatbot
        chatbot.run()
        
    except KeyboardInterrupt:
        print("\n\n👋 Thanks for using CryptoBuddy! Stay safe in the crypto world! 🚀")
    except Exception as e:
        print(f"\n❌ An unexpected error occurred: {e}")
        print("Please check your Python environment and try again.")
        sys.exit(1)

if __name__ == "__main__":
    main()
