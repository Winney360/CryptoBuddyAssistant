"""
CryptoBuddy chatbot implementation.
Main chatbot logic and response generation.
"""

import random
from crypto_data import (
    crypto_db, get_trending_cryptos, get_sustainable_cryptos, 
    get_low_energy_cryptos, get_long_term_recommendations, get_crypto_info
)
from nlp_utils import NLPProcessor
from api_client import CoinGeckoClient

class CryptoBuddy:
    """CryptoBuddy chatbot for cryptocurrency investment advice."""
    
    def __init__(self, use_live_data=True):
        self.nlp = NLPProcessor()
        self.api_client = CoinGeckoClient()
        self.use_live_data = use_live_data
        self.live_data = None
        self.session_active = True
        
        # Emoji responses for friendliness
        self.emojis = {
            'rocket': '🚀',
            'money': '💰',
            'green': '🌱',
            'chart': '📈',
            'warning': '⚠️',
            'thinking': '🤔',
            'wave': '👋',
            'star': '⭐',
            'fire': '🔥',
            'leaf': '🍃'
        }
        
        # Response templates
        self.responses = {
            'greeting': [
                f"{self.emojis['wave']} Hello! I'm CryptoBuddy, your friendly crypto investment advisor!",
                f"{self.emojis['rocket']} Hey there! Ready to explore the crypto universe together?",
                f"{self.emojis['star']} Hi! I'm here to help you navigate the exciting world of cryptocurrency!"
            ],
            'trending': [
                f"{self.emojis['fire']} {{coins}} {{is_are}} trending right now! {{trend_info}}",
                f"{self.emojis['chart']} {{coins}} {{is_are}} showing strong momentum! {{trend_info}}",
                f"{self.emojis['rocket']} {{coins}} {{is_are}} on fire lately! {{trend_info}}"
            ],
            'sustainable': [
                f"{self.emojis['green']} {{coins}} {{is_are}} leading the way in sustainable crypto! {{sustain_info}}",
                f"{self.emojis['leaf']} For eco-conscious investing, {{coins}} {{is_are}} excellent choice{{s}}! {{sustain_info}}",
                f"{self.emojis['green']} {{coins}} {{is_are}} perfect for environmentally-minded investors! {{sustain_info}}"
            ],
            'long_term': [
                f"{self.emojis['star']} For long-term growth, I recommend {{coins}}! {{long_term_info}}",
                f"{self.emojis['money']} {{coins}} {{is_are}} solid choice{{s}} for hodling! {{long_term_info}}",
                f"{self.emojis['rocket']} {{coins}} {{is_are}} built for the future! {{long_term_info}}"
            ],
            'energy': [
                f"{self.emojis['leaf']} {{coins}} use{{s}} minimal energy - great for the planet! {{energy_info}}",
                f"{self.emojis['green']} {{coins}} {{is_are}} energy-efficient and sustainable! {{energy_info}}"
            ],
            'default': [
                f"{self.emojis['thinking']} That's an interesting question! Let me share what I know about crypto...",
                f"{self.emojis['rocket']} I'd love to help! Here's some general crypto advice...",
                f"{self.emojis['star']} Great question! Here are some insights about cryptocurrency..."
            ]
        }
    
    def display_disclaimer(self):
        """Displays investment disclaimer."""
        disclaimer = f"""
{self.emojis['warning']} INVESTMENT DISCLAIMER {self.emojis['warning']}
═══════════════════════════════════════════════════════════

This chatbot provides educational information only and should NOT be 
considered as financial advice. Cryptocurrency investments are highly 
volatile and risky. Always:

• Do your own research (DYOR)
• Consult with qualified financial advisors
• Never invest more than you can afford to lose
• Consider your risk tolerance and investment goals

Past performance does not guarantee future results.
═══════════════════════════════════════════════════════════
        """
        print(disclaimer)
    
    def fetch_live_data_if_enabled(self):
        """Fetches live data if enabled and available."""
        if self.use_live_data:
            print(f"{self.emojis['rocket']} Checking for live cryptocurrency data...")
            self.live_data = self.api_client.fetch_live_data()
            if self.live_data:
                print(f"{self.emojis['chart']} Live data updated successfully!")
            else:
                print(f"{self.emojis['warning']} Using predefined data.")
    
    def get_current_data(self):
        """Returns current crypto data (live or predefined)."""
        if self.live_data:
            # Merge live data with predefined data
            merged_data = {}
            for name in crypto_db:
                merged_data[name] = {**crypto_db[name]}
                if name in self.live_data:
                    merged_data[name].update(self.live_data[name])
            return merged_data
        return crypto_db
    
    def generate_greeting(self):
        """Generates a random greeting."""
        greeting = random.choice(self.responses['greeting'])
        return greeting
    
    def format_coin_list(self, coins):
        """Formats a list of coins for display."""
        if not coins:
            return "No coins found", "are", ""
        
        if len(coins) == 1:
            return coins[0], "is", ""
        elif len(coins) == 2:
            return f"{coins[0]} and {coins[1]}", "are", "s"
        else:
            return f"{', '.join(coins[:-1])}, and {coins[-1]}", "are", "s"
    
    def handle_trending_query(self):
        """Handles queries about trending cryptocurrencies."""
        trending = get_trending_cryptos()
        if not trending:
            return f"{self.emojis['thinking']} No cryptocurrencies are showing strong upward trends right now. Consider doing more research!"
        
        coins_str, is_are, s = self.format_coin_list(trending)
        trend_info = "Perfect for momentum investors!"
        
        if self.live_data:
            # Add live price information if available
            price_info = []
            for coin in trending:
                if coin in self.live_data:
                    change = self.live_data[coin].get('price_change_24h', 0)
                    price_info.append(f"{coin} is up {change:.1f}%")
            if price_info:
                trend_info = f"{' and '.join(price_info)}!"
        
        template = random.choice(self.responses['trending'])
        return template.format(coins=coins_str, is_are=is_are, trend_info=trend_info)
    
    def handle_sustainable_query(self):
        """Handles queries about sustainable cryptocurrencies."""
        sustainable = get_sustainable_cryptos()
        if not sustainable:
            return f"{self.emojis['leaf']} All our tracked cryptos have room for improvement in sustainability!"
        
        coins_str, is_are, s = self.format_coin_list(sustainable)
        sustain_info = "Low environmental impact with high sustainability scores!"
        
        template = random.choice(self.responses['sustainable'])
        return template.format(coins=coins_str, is_are=is_are, sustain_info=sustain_info, s=s)
    
    def handle_energy_query(self):
        """Handles queries about energy-efficient cryptocurrencies."""
        low_energy = get_low_energy_cryptos()
        if not low_energy:
            return f"{self.emojis['warning']} Most cryptocurrencies use significant energy. Consider sustainability scores!"
        
        coins_str, is_are, s = self.format_coin_list(low_energy)
        energy_info = "These use proof-of-stake or other energy-efficient consensus mechanisms!"
        
        if len(low_energy) == 1:
            s_verb = "s"
        else:
            s_verb = ""
        
        template = random.choice(self.responses['energy'])
        return template.format(coins=coins_str, is_are=is_are, energy_info=energy_info, s=s_verb)
    
    def handle_long_term_query(self):
        """Handles queries about long-term investments."""
        long_term = get_long_term_recommendations()
        if not long_term:
            return f"{self.emojis['thinking']} Consider diversifying across multiple cryptocurrencies for long-term growth!"
        
        coins_str, is_are, s = self.format_coin_list(long_term)
        long_term_info = "Strong fundamentals and sustainable growth potential!"
        
        template = random.choice(self.responses['long_term'])
        return template.format(coins=coins_str, is_are=is_are, long_term_info=long_term_info, s=s)
    
    def handle_specific_crypto_query(self, crypto_names):
        """Handles queries about specific cryptocurrencies."""
        responses = []
        current_data = self.get_current_data()
        
        for crypto in crypto_names:
            info = current_data.get(crypto)
            if info:
                response = f"{self.emojis['star']} {crypto}: "
                details = []
                
                if info['price_trend'] == 'rising':
                    details.append(f"trending upward {self.emojis['chart']}")
                elif info['price_trend'] == 'stable':
                    details.append(f"stable price {self.emojis['money']}")
                
                if info['sustainability_score'] >= 7:
                    details.append(f"highly sustainable {self.emojis['green']}")
                elif info['sustainability_score'] >= 5:
                    details.append(f"moderately sustainable {self.emojis['leaf']}")
                
                if info['energy_use'] == 'low':
                    details.append(f"energy-efficient {self.emojis['leaf']}")
                
                if self.live_data and crypto in self.live_data:
                    price = self.live_data[crypto].get('current_price', 0)
                    change = self.live_data[crypto].get('price_change_24h', 0)
                    details.append(f"${price:,.2f} ({change:+.1f}%)")
                
                response += ", ".join(details) + "!"
                responses.append(response)
        
        return "\n".join(responses) if responses else self.handle_default_query()
    
    def handle_default_query(self):
        """Handles general or unrecognized queries."""
        template = random.choice(self.responses['default'])
        
        # Provide general crypto advice
        advice = [
            f"{self.emojis['rocket']} Bitcoin is the original cryptocurrency - great for beginners!",
            f"{self.emojis['green']} Cardano focuses on sustainability and long-term growth!",
            f"{self.emojis['chart']} Ethereum powers smart contracts and DeFi applications!",
            f"{self.emojis['star']} Always diversify your portfolio and never invest more than you can afford to lose!"
        ]
        
        return template + "\n" + random.choice(advice)
    
    def process_user_input(self, user_input):
        """Processes user input and generates appropriate response."""
        if not user_input.strip():
            return f"{self.emojis['thinking']} I didn't catch that. Could you ask me about crypto trends, sustainability, or investment advice?"
        
        # Check for exit conditions
        exit_phrases = ['bye', 'exit', 'quit', 'goodbye', 'farewell']
        if any(phrase in user_input.lower() for phrase in exit_phrases):
            self.session_active = False
            return f"{self.emojis['wave']} Thanks for chatting! Remember to invest wisely and stay curious about crypto! {self.emojis['rocket']}"
        
        # Detect intents using NLP
        intents = self.nlp.detect_intent(user_input)
        crypto_names = self.nlp.extract_crypto_names(user_input)
        
        # Handle specific cryptocurrency queries first
        if crypto_names:
            return self.handle_specific_crypto_query(crypto_names)
        
        # Handle intent-based queries
        if 'greeting' in intents:
            return self.generate_greeting()
        elif 'trending' in intents:
            return self.handle_trending_query()
        elif 'sustainable' in intents:
            return self.handle_sustainable_query()
        elif 'energy' in intents:
            return self.handle_energy_query()
        elif 'long_term' in intents:
            return self.handle_long_term_query()
        else:
            return self.handle_default_query()
    
    def run(self):
        """Main chatbot loop."""
        # Display disclaimer and greeting
        self.display_disclaimer()
        
        # Fetch live data if enabled
        self.fetch_live_data_if_enabled()
        
        # Initial greeting
        print(f"\n{self.generate_greeting()}")
        print(f"{self.emojis['money']} Ask me about trending coins, sustainable options, energy usage, or long-term investments!")
        print(f"{self.emojis['thinking']} Type 'bye' or 'exit' when you're done.\n")
        
        # Main conversation loop
        while self.session_active:
            try:
                user_input = input("You: ").strip()
                if user_input:
                    response = self.process_user_input(user_input)
                    print(f"CryptoBuddy: {response}\n")
                else:
                    print(f"CryptoBuddy: {self.emojis['thinking']} Feel free to ask me anything about cryptocurrency!\n")
            
            except KeyboardInterrupt:
                print(f"\n\nCryptoBuddy: {self.emojis['wave']} Goodbye! Happy investing! {self.emojis['rocket']}")
                break
            except Exception as e:
                print(f"CryptoBuddy: {self.emojis['warning']} Sorry, I encountered an error: {e}")
                print("Let's keep chatting about crypto!\n")
