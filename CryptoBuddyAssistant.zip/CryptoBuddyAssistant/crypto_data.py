"""
Cryptocurrency data module for CryptoBuddy chatbot.
Contains predefined crypto data and utility functions.
"""

# Predefined cryptocurrency database
crypto_db = {
    "Bitcoin": {
        "price_trend": "rising",
        "market_cap": "high",
        "energy_use": "high",
        "sustainability_score": 3,
        "symbol": "BTC",
        "description": "The original cryptocurrency and store of value"
    },
    "Ethereum": {
        "price_trend": "stable",
        "market_cap": "high",
        "energy_use": "medium",
        "sustainability_score": 6,
        "symbol": "ETH",
        "description": "Smart contract platform and second-largest crypto"
    },
    "Cardano": {
        "price_trend": "rising",
        "market_cap": "medium",
        "energy_use": "low",
        "sustainability_score": 8,
        "symbol": "ADA",
        "description": "Proof-of-stake blockchain focused on sustainability"
    }
}

def get_trending_cryptos():
    """Returns cryptocurrencies with rising price trends."""
    trending = []
    for name, data in crypto_db.items():
        if data["price_trend"] == "rising":
            trending.append(name)
    return trending

def get_sustainable_cryptos(min_score=7):
    """Returns cryptocurrencies with high sustainability scores."""
    sustainable = []
    for name, data in crypto_db.items():
        if data["sustainability_score"] >= min_score:
            sustainable.append(name)
    return sustainable

def get_low_energy_cryptos():
    """Returns cryptocurrencies with low energy usage."""
    low_energy = []
    for name, data in crypto_db.items():
        if data["energy_use"] == "low":
            low_energy.append(name)
    return low_energy

def get_long_term_recommendations():
    """Returns cryptocurrencies suitable for long-term investment."""
    recommendations = []
    for name, data in crypto_db.items():
        # Consider coins with good sustainability and stable/rising trends
        if (data["sustainability_score"] >= 6 and 
            data["price_trend"] in ["rising", "stable"]):
            recommendations.append(name)
    return recommendations

def get_crypto_info(crypto_name):
    """Returns detailed information about a specific cryptocurrency."""
    crypto_name_formatted = crypto_name.title()
    return crypto_db.get(crypto_name_formatted)
