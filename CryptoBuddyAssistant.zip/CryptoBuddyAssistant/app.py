#!/usr/bin/env python3
"""
CryptoBuddy Web Application - Flask version
A friendly cryptocurrency investment advice chatbot with web interface.
"""

from flask import Flask, render_template, request, jsonify
import json
from chatbot import CryptoBuddy

app = Flask(__name__)

# Initialize the chatbot - will be created per request to avoid state issues
crypto_buddy = None

@app.route('/')
def index():
    """Main page route."""
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """API endpoint for chatbot interaction."""
    try:
        # Initialize chatbot for each request without live data to avoid API issues
        chatbot = CryptoBuddy(use_live_data=False)
        
        data = request.get_json()
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({
                'response': "🤔 I didn't catch that. Could you ask me about crypto trends, sustainability, or investment advice?",
                'status': 'success'
            })
        
        # Process the user input
        response = chatbot.process_user_input(user_message)
        
        # Check if session should end
        session_active = chatbot.session_active
        
        return jsonify({
            'response': response,
            'session_active': session_active,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'response': f"⚠️ Sorry, I encountered an error: {str(e)}",
            'status': 'error'
        })

@app.route('/api/disclaimer')
def get_disclaimer():
    """Get the investment disclaimer."""
    disclaimer = """⚠️ INVESTMENT DISCLAIMER ⚠️

This chatbot provides educational information only and should NOT be considered as financial advice. Cryptocurrency investments are highly volatile and risky. Always:

• Do your own research (DYOR)
• Consult with qualified financial advisors  
• Never invest more than you can afford to lose
• Consider your risk tolerance and investment goals

Past performance does not guarantee future results."""
    
    return jsonify({
        'disclaimer': disclaimer,
        'status': 'success'
    })

@app.route('/api/greeting')
def get_greeting():
    """Get initial greeting message."""
    chatbot = CryptoBuddy(use_live_data=True)
    greeting = chatbot.generate_greeting()
    return jsonify({
        'greeting': greeting,
        'status': 'success'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)