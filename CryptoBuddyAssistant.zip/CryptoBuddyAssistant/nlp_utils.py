"""
Natural Language Processing utilities for CryptoBuddy chatbot.
Handles text processing and intent recognition.
"""

import re
import os

# Try to import NLTK if available
try:
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import PorterStemmer
    
    # Download required NLTK data if not present
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        print("📥 Downloading NLTK punkt data...")
        nltk.download('punkt', quiet=True)
        
    try:
        nltk.data.find('tokenizers/punkt_tab')
    except LookupError:
        print("📥 Downloading NLTK punkt_tab data...")
        nltk.download('punkt_tab', quiet=True)
        
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        print("📥 Downloading NLTK stopwords data...")
        nltk.download('stopwords', quiet=True)
    
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False
    print("ℹ️  NLTK not available. Using basic text processing.")

class NLPProcessor:
    """Handles natural language processing for user queries."""
    
    def __init__(self):
        self.stemmer = PorterStemmer() if NLTK_AVAILABLE else None
        self.stop_words = set(stopwords.words('english')) if NLTK_AVAILABLE else set()
        
        # Define intent keywords
        self.intent_keywords = {
            'trending': ['trend', 'trending', 'hot', 'popular', 'rising', 'up', 'bullish'],
            'sustainable': ['sustainable', 'green', 'eco', 'environment', 'carbon', 'energy efficient'],
            'energy': ['energy', 'power', 'consumption', 'efficient', 'low energy'],
            'long_term': ['long', 'term', 'future', 'investment', 'hold', 'hodl', 'years'],
            'price': ['price', 'cost', 'value', 'worth', 'expensive', 'cheap'],
            'investment': ['invest', 'buy', 'purchase', 'recommend', 'advice', 'suggest'],
            'greeting': ['hello', 'hi', 'hey', 'greetings', 'good', 'morning', 'afternoon', 'evening'],
            'goodbye': ['bye', 'goodbye', 'exit', 'quit', 'farewell', 'see you']
        }
    
    def tokenize_and_process(self, text):
        """Tokenizes and processes user input."""
        text = text.lower().strip()
        
        if NLTK_AVAILABLE:
            # Use NLTK for advanced processing
            tokens = word_tokenize(text)
            # Remove stopwords and stem
            processed_tokens = [
                self.stemmer.stem(token) for token in tokens 
                if token.isalnum() and token not in self.stop_words
            ]
        else:
            # Basic processing without NLTK
            # Remove punctuation and split
            text = re.sub(r'[^\w\s]', ' ', text)
            tokens = text.split()
            processed_tokens = [token for token in tokens if len(token) > 2]
        
        print(f"🔍 Detected tokens: {processed_tokens}")
        return tokens, processed_tokens
    
    def detect_intent(self, text):
        """Detects user intent from the input text."""
        _, processed_tokens = self.tokenize_and_process(text)
        
        detected_intents = []
        
        for intent, keywords in self.intent_keywords.items():
            for token in processed_tokens:
                for keyword in keywords:
                    if NLTK_AVAILABLE:
                        # Use stemming for better matching
                        if self.stemmer.stem(token) == self.stemmer.stem(keyword):
                            detected_intents.append(intent)
                            break
                    else:
                        # Simple substring matching
                        if keyword in token or token in keyword:
                            detected_intents.append(intent)
                            break
        
        # Remove duplicates while preserving order
        unique_intents = []
        for intent in detected_intents:
            if intent not in unique_intents:
                unique_intents.append(intent)
        
        return unique_intents
    
    def extract_crypto_names(self, text):
        """Extracts cryptocurrency names from user input."""
        crypto_names = ['bitcoin', 'btc', 'ethereum', 'eth', 'cardano', 'ada']
        mentioned_cryptos = []
        
        text_lower = text.lower()
        for crypto in crypto_names:
            if crypto in text_lower:
                # Map symbols to full names
                if crypto in ['btc', 'bitcoin']:
                    mentioned_cryptos.append('Bitcoin')
                elif crypto in ['eth', 'ethereum']:
                    mentioned_cryptos.append('Ethereum')
                elif crypto in ['ada', 'cardano']:
                    mentioned_cryptos.append('Cardano')
        
        return list(set(mentioned_cryptos))  # Remove duplicates
