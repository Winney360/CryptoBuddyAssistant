"""
API client for fetching live cryptocurrency data from CoinGecko.
"""

import os
import json

# Try to import requests if available
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("ℹ️  requests library not available. Live data fetching disabled.")

class CoinGeckoClient:
    """Client for interacting with CoinGecko API."""
    
    def __init__(self):
        self.base_url = "https://api.coingecko.com/api/v3"
        self.coin_ids = {
            'Bitcoin': 'bitcoin',
            'Ethereum': 'ethereum',
            'Cardano': 'cardano'
        }
    
    def fetch_live_data(self):
        """Fetches live cryptocurrency data from CoinGecko."""
        if not REQUESTS_AVAILABLE:
            print("❌ Cannot fetch live data: requests library not available")
            return None
        
        try:
            # Fetch market data for our supported cryptocurrencies
            coin_ids = ','.join(self.coin_ids.values())
            url = f"{self.base_url}/coins/markets"
            params = {
                'vs_currency': 'usd',
                'ids': coin_ids,
                'order': 'market_cap_desc',
                'per_page': 3,
                'page': 1,
                'sparkline': False,
                'price_change_percentage': '24h'
            }
            
            print("📡 Fetching live cryptocurrency data...")
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            return self.process_live_data(data)
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Error fetching live data: {e}")
            return None
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return None
    
    def process_live_data(self, api_data):
        """Processes live data and updates our crypto database format."""
        processed_data = {}
        
        for coin in api_data:
            # Map CoinGecko data to our format
            name = self.get_name_from_id(coin['id'])
            if name:
                # Determine price trend based on 24h change
                price_change = coin.get('price_change_percentage_24h', 0)
                if price_change > 5:
                    trend = "rising"
                elif price_change < -5:
                    trend = "falling"
                else:
                    trend = "stable"
                
                # Determine market cap category
                market_cap = coin.get('market_cap', 0)
                if market_cap > 100_000_000_000:  # > 100B
                    cap_category = "high"
                elif market_cap > 10_000_000_000:  # > 10B
                    cap_category = "medium"
                else:
                    cap_category = "low"
                
                processed_data[name] = {
                    "price_trend": trend,
                    "market_cap": cap_category,
                    "current_price": coin.get('current_price', 0),
                    "price_change_24h": price_change,
                    "market_cap_value": market_cap,
                    "last_updated": coin.get('last_updated', '')
                }
        
        return processed_data
    
    def get_name_from_id(self, coin_id):
        """Maps CoinGecko coin ID to our cryptocurrency names."""
        for name, id_value in self.coin_ids.items():
            if id_value == coin_id:
                return name
        return None
